/* 
  MorseCode.h  - Library for flashing MorseCode code.
  Created - Mark Jordan, 12/29/2022
  Released into the public domain.
*/
#ifndef MorseCode_h
#define MorseCode_h
#include "Arduino.h"
class MorseCode
{
  public:
    MorseCode(int pin);
    void dit();
    void dah();
    void a();
    void b();
    void c();
    void d();
    void e();
    void f();
    void g();
    void h();
    void i();
    void j();
    void k();
    void l();
    void m();
    void n();
    void o();
    void p();
    void q();
    void r();
    void s();
    void t();
    void u();
    void v();
    void w();
    void x();
    void y();
    void z();
  private:
    int _pin;
};
#endif