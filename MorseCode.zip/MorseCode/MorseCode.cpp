#include "Arduino.h"
#include "MorseCode.h"
MorseCode::MorseCode(int pin)
{
  pinMode(pin, OUTPUT);
  _pin = pin;
}
void MorseCode::dit(){
  digitalWrite(_pin, HIGH);  // turn the LED on
  delay(150);                // wait for a 150 ms
  digitalWrite(_pin, LOW);   // turn the LED off
  delay(300);                // wait for 300 ms
}
void MorseCode::dah(){
  digitalWrite(_pin, HIGH);  // turn the LED on
  delay(500);                // wait for a 500 ms       
  digitalWrite(_pin, LOW);   // turn the LED off
  delay(300);                // wait for 300 ms       
}
void MorseCode::a(){
	dit();
	dah();
    delay(500);
}
void MorseCode::b(){
	dah();
	dit();
	dit();
	dit();
    delay(500);
}
void MorseCode::c(){
	dah();
	dit();
	dah();
	dit();
    delay(500);
}
void MorseCode::d(){
	dah();
	dit();
	dit();
    delay(500);
}
void MorseCode::e(){
	dit();
    delay(500);
}
void MorseCode::f(){
	dit();
	dit();
	dah();
	dit();
    delay(500);
}
void MorseCode::g(){
	dah();
	dah();
	dit();
    delay(500);
}
void MorseCode::h(){
	dit();
	dit();
	dit();
	dit();
    delay(500);
}
void MorseCode::i(){
	dit();
	dit();
    delay(500);
}
void MorseCode::j(){
	dit();
	dah();
	dah();
	dah();
    delay(500);
}
void MorseCode::k(){
	dah();
	dit();
	dah();
    delay(500);
}
void MorseCode::l(){
	dit();
	dah();
	dit();
	dit();
    delay(500);
}
void MorseCode::m(){
	dah();
	dah();
    delay(500);
}
void MorseCode::n(){
	dah();
	dit();
    delay(500);
}
void MorseCode::o(){
	dah();
	dah();
	dah();
    delay(500);
}
void MorseCode::p(){
	dit();
	dah();
	dah();
	dit();
    delay(500);
}
void MorseCode::q(){
	dah();
	dah();
	dit();
	dah();
    delay(500);
}
void MorseCode::r(){
	dit();
	dah();
	dit();
    delay(500);
}
void MorseCode::s(){
	dit();
	dit();
	dit();
    delay(500);
}
void MorseCode::t(){
	dah();
    delay(500);
}
void MorseCode::u(){
	dit();
	dit();
	dah();
    delay(500);
}
void MorseCode::v(){
	dit();
	dit();
	dit();
	dah();
    delay(500);
}
void MorseCode::w(){
	dit();
	dah();
	dah();
    delay(500);
}
void MorseCode::x(){
	dah();
	dit();
	dit();
	dah();
    delay(500);
}
void MorseCode::y(){
	dah();
	dit();
	dah();
	dah();
    delay(500);
}
void MorseCode::z(){
	dah();
	dah();
	dit();
	dit();
    delay(500);
}
